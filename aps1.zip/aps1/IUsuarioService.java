package aps1;

import java.util.List;

//Interface da camada de serviço para Usuarios
public interface IUsuarioService {
    void cadastrarUsuario(Usuario usuario);
    Usuario buscarPorId(String id);
    List<Tecnico> listarTecnicosDisponiveis();
    List<Tecnico> listarTodosTecnicos();
}