package aps1;

import java.util.List;

//Interface da camada de serviço para Equipamentos
public interface IEquipamentoService {
 void cadastrar(Equipamento equipamento);
 void inativar(String idEquipamento);
 List<Equipamento> listarTodos();
}