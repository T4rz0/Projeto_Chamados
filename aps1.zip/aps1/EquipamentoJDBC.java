package aps1;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

//Responsável por realizar a persistência e consulta dos dados de Equipamentos no banco
public class EquipamentoJDBC implements EquipamentoRepositorio {

	//Salva ou atualiza um equipamento no banco de dados.
    @Override
    public void salvar(Equipamento equipamento) {
        String sql = "INSERT INTO Equipamento (id, nome, modelo, ativo) VALUES (?, ?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE nome = VALUES(nome), modelo = VALUES(modelo), ativo = VALUES(ativo)";
        
        try (Connection conn = ConexãoSQL.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, equipamento.getId());
            stmt.setString(2, equipamento.getNome());
            stmt.setString(3, equipamento.getModelo());
            stmt.setBoolean(4, equipamento.isAtivo());
            
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao salvar equipamento no banco de dados", e);
        }
    }

    //Busca um equipamento específico pelo seu ID único.
    @Override
    public Optional<Equipamento> buscarPorId(String id) {
        String sql = "SELECT * FROM Equipamento WHERE id = ?";
        
        try (Connection conn = ConexãoSQL.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                Equipamento eq = new Equipamento(
                    rs.getString("id"),
                    rs.getString("nome"),
                    rs.getString("modelo")
                );
                if (!rs.getBoolean("ativo")) {
                    eq.inativar();
                }
                return Optional.of(eq);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar equipamento por ID", e);
        }
        return Optional.empty();
    }

    //Retorna uma lista com todos os equipamentos cadastrados no banco de dados
    @Override
    public List<Equipamento> listarTodos() {
        List<Equipamento> lista = new ArrayList<>();
        String sql = "SELECT * FROM Equipamento";
        
        try (Connection conn = ConexãoSQL.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Equipamento eq = new Equipamento(
                    rs.getString("id"),
                    rs.getString("nome"),
                    rs.getString("modelo")
                );
             // Restaura o estado inativo caso esteja falso no banco
                if (!rs.getBoolean("ativo")) {
                    eq.inativar();
                }
                lista.add(eq);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar equipamentos", e);
        }
        return lista;
    }
}
