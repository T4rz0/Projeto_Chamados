package aps1;

//Enum para os diferentes estados de uma Ordem de Serviço
public enum StatusOS {
	ABERTA, EM_EXECUCAO, FECHADA, CANCELADA, REPARO_FINALIZADO, AGUARDANDO_PECA
}
