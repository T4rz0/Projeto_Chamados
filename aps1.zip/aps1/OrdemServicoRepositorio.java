package aps1;
import java.util.List;
import java.util.Optional;

//Interface que define o contrato de persistência para a classe OrdemServico
public interface OrdemServicoRepositorio {
	void salvar(OrdemDeServico os);
    List<OrdemDeServico> listarTodas();
    Optional<OrdemDeServico> buscarPorId(String id);
}
