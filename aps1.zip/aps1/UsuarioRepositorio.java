package aps1;
import java.util.List;
import java.util.Optional;

//Interface que define o contrato de persistência para a classe Usuario
public interface UsuarioRepositorio {
	void salvar(Usuario usuario);
	List<Tecnico> listarTecnicos();
	Optional<Usuario> buscarPorId(String id);
}
