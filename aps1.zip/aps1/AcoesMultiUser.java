package aps1;
import java.util.List;

// Interface que define ações compartilhadas por ambos gestores e técnicos.
public interface AcoesMultiUser {
	List<Equipamento> listarEquipamentos();
    List<OrdemDeServico> listarOrdensServico();
    OrdemDeServico abrirChamado(String id, String idEquipamento, String falha, String criticidade);
    List<Tecnico> consultarDisponibilidadeTecnicos();
}
