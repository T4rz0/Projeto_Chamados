package aps1;
import java.util.List;
import java.util.Optional;

//Interface que define o contrato de persistência para a classe Equipamento
public interface EquipamentoRepositorio {
	void salvar(Equipamento equipamento);
    List<Equipamento> listarTodos();
    Optional<Equipamento> buscarPorId(String id);
}
