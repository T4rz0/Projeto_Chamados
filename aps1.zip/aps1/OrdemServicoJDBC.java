package aps1;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

//Responsável por persistir e reconstruir o ciclo de vida completo dos chamados, incluindo relacionamentos com equipamentos, técnicos e o histórico de intervenções.
public class OrdemServicoJDBC implements OrdemServicoRepositorio {

    private final EquipamentoRepositorio equipRepo;
    private final UsuarioRepositorio userRepo;

    // Injeção dos outros repositórios para reconstruir os relacionamentos do objeto OrdemDeServico
    public OrdemServicoJDBC(EquipamentoRepositorio equipRepo, UsuarioRepositorio userRepo) {
        this.equipRepo = equipRepo;
        this.userRepo = userRepo;
    }

    //Salva ou atualiza uma Ordem de Serviço e seus históricos associados no banco de dados
    @Override
    public void salvar(OrdemDeServico os) {
        String sqlOS = "INSERT INTO Ordem_Servico (id, equipamento_id, tecnico_id, descricao_falha, criticidade, status_os, diagnostico) " +
                       "VALUES (?, ?, ?, ?, ?, ?, ?) " +
                       "ON DUPLICATE KEY UPDATE tecnico_id = VALUES(tecnico_id), status_os = VALUES(status_os), diagnostico = VALUES(diagnostico)";

        try (Connection conn = ConexãoSQL.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sqlOS)) {

            stmt.setString(1, os.getId());
            stmt.setString(2, os.getEquipamento().getId());

            // Trata o técnico alocado (pode ser nulo caso a OS esteja recém-aberta)
            if (os.getTecnicoAlocado() != null) {
                stmt.setString(3, os.getTecnicoAlocado().getId());
            } else {
                stmt.setNull(3, Types.VARCHAR);
            }

            stmt.setString(4, os.getDescricaoFalha());
            stmt.setString(5, os.getCriticidade());
            stmt.setString(6, os.getStatus().name());
            stmt.setString(7, os.getDiagnostico());

            stmt.executeUpdate();

            // Salva os novos registros do histórico associados a esta OS
            salvarHistorico(conn, os);

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao salvar ordem de serviço no banco de dados", e);
        }
    }

    //Busca uma Ordem de Serviço específica pelo seu ID
    @Override
    public Optional<OrdemDeServico> buscarPorId(String id) {
        String sql = "SELECT * FROM Ordem_Servico WHERE id = ?";

        try (Connection conn = ConexãoSQL.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return Optional.of(mapearOS(conn, rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar ordem de serviço por ID", e);
        }
        return Optional.empty();
    }

    //Lista todas as Ordens de Serviço cadastradas na base de dados
    @Override
    public List<OrdemDeServico> listarTodas() {
        List<OrdemDeServico> lista = new ArrayList<>();
        String sql = "SELECT * FROM Ordem_Servico";

        try (Connection conn = ConexãoSQL.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                lista.add(mapearOS(conn, rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar ordens de serviço", e);
        }
        return lista;
    }

    // Persiste os itens do histórico de intervenções na tabela Registro_Historico
    private void salvarHistorico(Connection conn, OrdemDeServico os) throws SQLException {
        // Apaga os registros antigos dessa OS e reinsere para manter a sincronia simplificada
        String sqlDelete = "DELETE FROM Registro_Historico WHERE ordem_servico_id = ?";
        try (PreparedStatement stmtDel = conn.prepareStatement(sqlDelete)) {
            stmtDel.setString(1, os.getId());
            stmtDel.executeUpdate();
        }

        String sqlInsert = "INSERT INTO Registro_Historico (ordem_servico_id, data_hora, descricao, horas_trabalhadas, materiais_utilizados) " +
                           "VALUES (?, NOW(), ?, ?, ?)";

        try (PreparedStatement stmtIns = conn.prepareStatement(sqlInsert)) {
            for (RegistroHistorico reg : os.getHistoricoDosRegistros()) {
                stmtIns.setString(1, os.getId());
                stmtIns.setString(2, reg.getDescricao());
                stmtIns.setDouble(3, reg.getHorasTrabalhadas());
                stmtIns.setString(4, reg.getMateriaisUtilizados());
                stmtIns.executeUpdate();
            }
        }
    }

    // Mapeia a linha do banco para a entidade OrdemDeServico reconstruindo os relacionamentos
    private OrdemDeServico mapearOS(Connection conn, ResultSet rs) throws SQLException {
        String id = rs.getString("id");
        String equipId = rs.getString("equipamento_id");
        String tecId = rs.getString("tecnico_id");
        String falha = rs.getString("descricao_falha");
        String criticidade = rs.getString("criticidade");
        String statusStr = rs.getString("status_os");
        String diagnostico = rs.getString("diagnostico");

        Equipamento equip = equipRepo.buscarPorId(equipId)
                .orElseThrow(() -> new IllegalStateException("Equipamento não encontrado ID: " + equipId));

        OrdemDeServico os = new OrdemDeServico(id, equip, falha, criticidade);

        // Reconstrói o estado interno da OS de acordo com os dados gravados
        if (tecId != null) {
            Tecnico tec = (Tecnico) userRepo.buscarPorId(tecId)
                    .orElseThrow(() -> new IllegalStateException("Técnico não encontrado ID: " + tecId));
            os.atribuirTecnico(tec);
        }

        if (diagnostico != null) {
            os.registrarDiagnostico(diagnostico);
        }

        StatusOS statusNoBanco = StatusOS.valueOf(statusStr);
        if (statusNoBanco == StatusOS.REPARO_FINALIZADO) {
            os.concluirTecnicamente();
        } else if (statusNoBanco == StatusOS.FECHADA) {
            os.concluirTecnicamente();
            os.fecharPeloGestor();
        } else if (statusNoBanco != StatusOS.ABERTA && statusNoBanco != StatusOS.EM_EXECUCAO) {
            os.atualizarStatusOperacional(statusNoBanco);
        }

        // Carrega o histórico de registros
        carregarHistorico(conn, os);

        return os;
    }

    //Carrega os registros de histórico do banco e os adiciona à instância da OS
    private void carregarHistorico(Connection conn, OrdemDeServico os) throws SQLException {
        String sql = "SELECT * FROM Registro_Historico WHERE ordem_servico_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, os.getId());
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                os.adicionarRegistro(
                    rs.getString("descricao"),
                    rs.getDouble("horas_trabalhadas"),
                    rs.getString("materiais_utilizados")
                );
            }
        }
    }
}