package aps1;

//Representa o perfil de usuário Gestor no sistema
public class Gestor extends Usuario{

	public Gestor(String id, String nome, String email) {
		super(id, nome, email, TipoUsuario.GESTOR);
	}
	
}
