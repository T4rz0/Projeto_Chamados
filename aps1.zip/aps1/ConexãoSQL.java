package aps1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//Classe responsável por gerenciar e fornecer a conexão com o banco de dados MySQL
public class ConexãoSQL {
	
	// Configurações de acesso ao banco de dados (URL, credenciais)
    private static final String URL = "jdbc:mysql://localhost:3306/chamados_projeto?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root"; // Altere para seu usuário do MySQL
    private static final String PASSWORD = "senha"; // Altere para sua senha do MySQL

    //Estabelece e retorna uma nova conexão ativa com o banco de dados.
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
