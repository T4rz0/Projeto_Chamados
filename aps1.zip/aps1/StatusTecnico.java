package aps1;

//Enum para os diferentes estados de um Técnico
public enum StatusTecnico {
	DISPONIVEL, EM_ATENDIMENTO, AUSENTE
}
