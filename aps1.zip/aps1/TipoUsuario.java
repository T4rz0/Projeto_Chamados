package aps1;

//Enum para os dois tipos de usuarios(Tecnico e Gestor)
public enum TipoUsuario {
	TECNICO, GESTOR
}
