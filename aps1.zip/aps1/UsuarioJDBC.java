package aps1;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

//Gerencia a persistência e o mapeamento polimórfico de usuários (Gestores e Técnicos) na base de dados relacional.
public class UsuarioJDBC implements UsuarioRepositorio {

	//Salva ou atualiza um usuário no banco de dados, caso o usuário seja um Técnico, persiste também o seu status operacional específico.
    @Override
    public void salvar(Usuario usuario) {
        String sql = "INSERT INTO Usuario (id, nome, email, tipo_usuario, status_tecnico) VALUES (?, ?, ?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE nome = VALUES(nome), email = VALUES(email), " +
                     "tipo_usuario = VALUES(tipo_usuario), status_tecnico = VALUES(status_tecnico)";

        try (Connection conn = ConexãoSQL.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, usuario.getId());
            stmt.setString(2, usuario.getNome());
            stmt.setString(3, usuario.getEmail());
            stmt.setString(4, usuario.getTipo().name());

         // Verifica se o usuário é um Técnico para salvar o status específico
            if (usuario instanceof Tecnico tecnico) {
                stmt.setString(5, tecnico.getStatusTec().name());
            } else {
                stmt.setNull(5, Types.VARCHAR);
            }

            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao salvar usuário no banco de dados", e);
        }
    }

    //Busca um usuário específico pelo seu ID único.
    @Override
    public Optional<Usuario> buscarPorId(String id) {
        String sql = "SELECT * FROM Usuario WHERE id = ?";

        try (Connection conn = ConexãoSQL.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return Optional.of(mapearUsuario(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar usuário por ID", e);
        }
        return Optional.empty();
    }

    //Retorna uma lista contendo apenas os usuários cadastrados com o perfil de Técnico.
    @Override
    public List<Tecnico> listarTecnicos() {
        List<Tecnico> tecnicos = new ArrayList<>();
        String sql = "SELECT * FROM Usuario WHERE tipo_usuario = 'TECNICO'";

        try (Connection conn = ConexãoSQL.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                tecnicos.add((Tecnico) mapearUsuario(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar técnicos", e);
        }
        return tecnicos;
    }

    // Método privado auxiliar para mapear o ResultSet para o objeto correto da hierarquia (Gestor ou Tecnico)
    private Usuario mapearUsuario(ResultSet rs) throws SQLException {
        String id = rs.getString("id");
        String nome = rs.getString("nome");
        String email = rs.getString("email");
        String tipoStr = rs.getString("tipo_usuario");

        if ("TECNICO".equalsIgnoreCase(tipoStr)) {
            String statusStr = rs.getString("status_tecnico");
            StatusTecnico status = statusStr != null ? StatusTecnico.valueOf(statusStr) : StatusTecnico.DISPONIVEL;
            return new Tecnico(id, nome, email, status);
        } else {
            return new Gestor(id, nome, email);
        }
    }
}