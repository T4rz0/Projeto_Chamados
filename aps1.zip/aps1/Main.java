package aps1;

import java.util.List;
import java.util.Scanner;

public class Main {

    private static Scanner scanner = new Scanner(System.in);
    
    // Instanciação da camada de dados e serviços conectados ao MySQL
    private static EquipamentoRepositorio equipRepo = new EquipamentoJDBC();
    private static UsuarioRepositorio userRepo = new UsuarioJDBC();
    private static OrdemServicoRepositorio osRepo = new OrdemServicoJDBC(equipRepo, userRepo);

    private static IEquipamentoService equipService = new EquipamentoService(equipRepo);
    private static IUsuarioService userService = new UsuarioService(userRepo);
    private static IOS_Service osService = new OS_Service(osRepo, equipRepo);

    public static void main(String[] args) {
        System.out.println("==================================================");
        System.out.println("   SISTEMA DE GESTÃO DE MANUTENÇÃO (SGM-APS)     ");
        System.out.println("==================================================");

        System.out.print("Informe o seu ID de Usuário para entrar: ");
        String idUsuario = scanner.nextLine().trim();

        try {
            Usuario usuarioLogado = userService.buscarPorId(idUsuario);
            System.out.println("\nBem-vindo(a), " + usuarioLogado.getNome() + "!");
            System.out.println("Perfil identificado: " + usuarioLogado.getTipo());

            if (usuarioLogado instanceof Gestor gestor) {
                exibirMenuGestor(gestor);
            } else if (usuarioLogado instanceof Tecnico tecnico) {
                exibirMenuTecnico(tecnico);
            }
        } catch (IllegalArgumentException e) {
            System.err.println("\nErro de autenticação: " + e.getMessage());
            System.out.println("Encerrando a aplicação.");
        }
    }

    // ==========================================
    // MENU E OPERAÇÕES DO GESTOR
    // ==========================================
    private static void exibirMenuGestor(Gestor gestor) {
        boolean rodando = true;
        while (rodando) {
            System.out.println("\n----------------------------------");
            System.out.println("        PAINEL DO GESTOR          ");
            System.out.println("----------------------------------");
            System.out.println("1. Cadastrar Equipamento");
            System.out.println("2. Inativar Equipamento");
            System.out.println("3. Cadastrar Novo Usuário (Gestor/Técnico)");
            System.out.println("4. Abrir Ordem de Serviço");
            System.out.println("5. Atribuir Técnico a uma OS");
            System.out.println("6. Fechar OS (Finalizar Processo)");
            System.out.println("7. Listar Todos os Equipamentos");
            System.out.println("8. Listar Todas as Ordens de Serviço");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");

            int opcao = lerOpcaoInt();

            switch (opcao) {
                case 1 -> {
                    try {
                        System.out.print("ID do Equipamento: ");
                        String id = scanner.nextLine();
                        System.out.print("Nome: ");
                        String nome = scanner.nextLine();
                        System.out.print("Modelo: ");
                        String modelo = scanner.nextLine();

                        Equipamento eq = new Equipamento(id, nome, modelo);
                        equipService.cadastrar(eq);
                        System.out.println("✓ Equipamento cadastrado com sucesso!");
                    } catch (Exception e) {
                        System.err.println("Erro ao cadastrar equipamento: " + e.getMessage());
                    }
                }
                case 2 -> {
                    try {
                        System.out.print("ID do Equipamento a inativar: ");
                        String id = scanner.nextLine();
                        equipService.inativar(id);
                        System.out.println("✓ Equipamento inativado com sucesso!");
                    } catch (Exception e) {
                        System.err.println("Erro ao inativar equipamento: " + e.getMessage());
                    }
                }
                case 3 -> {
                    try {
                        System.out.print("ID do Usuário: ");
                        String id = scanner.nextLine();
                        System.out.print("Nome: ");
                        String nome = scanner.nextLine();
                        System.out.print("Email: ");
                        String email = scanner.nextLine();
                        System.out.print("Tipo (1 - Gestor | 2 - Técnico): ");
                        int tipo = lerOpcaoInt();

                        Usuario usuario;
                        if (tipo == 1) {
                            usuario = new Gestor(id, nome, email);
                        } else if (tipo == 2) {
                            usuario = new Tecnico(id, nome, email, StatusTecnico.DISPONIVEL);
                        } else {
                            System.out.println("Tipo inválido.");
                            break;
                        }

                        userService.cadastrarUsuario(usuario);
                        System.out.println("✓ Usuário cadastrado com sucesso!");
                    } catch (Exception e) {
                        System.err.println("Erro ao cadastrar usuário: " + e.getMessage());
                    }
                }
                case 4 -> {
                    try {
                        System.out.print("ID da nova OS: ");
                        String idOS = scanner.nextLine();
                        System.out.print("ID do Equipamento: ");
                        String idEquip = scanner.nextLine();
                        System.out.print("Descrição da Falha: ");
                        String falha = scanner.nextLine();
                        System.out.print("Criticidade (BAIXA / MEDIA / ALTA): ");
                        String criticidade = scanner.nextLine();

                        osService.abrirChamado(idOS, idEquip, falha, criticidade);
                        System.out.println("✓ Ordem de Serviço aberta com sucesso!");
                    } catch (Exception e) {
                        System.err.println("Erro ao abrir OS: " + e.getMessage());
                    }
                }
                case 5 -> {
                    try {
                        System.out.print("ID da OS: ");
                        String idOS = scanner.nextLine();
                        System.out.print("ID do Técnico: ");
                        String idTecnico = scanner.nextLine();

                        Usuario u = userService.buscarPorId(idTecnico);
                        if (u instanceof Tecnico tec) {
                            osService.atribuirTecnico(idOS, tec);
                            System.out.println("✓ Técnico atribuído com sucesso!");
                        } else {
                            System.err.println("O ID informado não pertence a um Técnico.");
                        }
                    } catch (Exception e) {
                        System.err.println("Erro ao atribuir técnico: " + e.getMessage());
                    }
                }
                case 6 -> {
                    try {
                        System.out.print("ID da OS a ser fechada: ");
                        String idOS = scanner.nextLine();
                        osService.fecharPeloGestor(idOS);
                        System.out.println("✓ OS fechada com sucesso!");
                    } catch (Exception e) {
                        System.err.println("Erro ao fechar OS: " + e.getMessage());
                    }
                }
                case 7 -> {
                    List<Equipamento> lista = equipService.listarTodos();
                    System.out.println("\n--- LISTA DE EQUIPAMENTOS ---");
                    if (lista.isEmpty()) {
                        System.out.println("Nenhum equipamento cadastrado.");
                    } else {
                        lista.forEach(e -> System.out.printf("[%s] %s - Modelo: %s | Ativo: %s\n", 
                                e.getId(), e.getNome(), e.getModelo(), e.isAtivo() ? "Sim" : "Não"));
                    }
                }
                case 8 -> {
                    List<OrdemDeServico> lista = osService.listarTodas();
                    System.out.println("\n--- LISTA DE ORDENS DE SERVIÇO ---");
                    if (lista.isEmpty()) {
                        System.out.println("Nenhuma Ordem de Serviço encontrada.");
                    } else {
                        lista.forEach(os -> {
                            String tecNome = os.getTecnicoAlocado() != null ? os.getTecnicoAlocado().getNome() : "Sem Técnico";
                            System.out.printf("[%s] Equipamento: %s | Falha: %s | Status: %s | Técnico: %s\n",
                                    os.getId(), os.getEquipamento().getNome(), os.getDescricaoFalha(), os.getStatus(), tecNome);
                        });
                    }
                }
                case 0 -> {
                    System.out.println("Saindo do sistema... Até logo!");
                    rodando = false;
                }
                default -> System.out.println("Opção inválida! Tente novamente.");
            }
        }
    }

    // ==========================================
    // MENU E OPERAÇÕES DO TÉCNICO
    // ==========================================
    private static void exibirMenuTecnico(Tecnico tecnico) {
        boolean rodando = true;
        while (rodando) {
            System.out.println("\n----------------------------------");
            System.out.println("        PAINEL DO TÉCNICO         ");
            System.out.println("        Status: " + tecnico.getStatusTec());
            System.out.println("----------------------------------");
            System.out.println("1. Registrar Diagnóstico da OS");
            System.out.println("2. Registrar Intervenção (Horas e Peças)");
            System.out.println("3. Finalizar Manutenção Técnica");
            System.out.println("4. Marcar Minha Ausência");
            System.out.println("5. Listar Ordens de Serviço");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");

            int opcao = lerOpcaoInt();

            switch (opcao) {
                case 1 -> {
                    try {
                        System.out.print("ID da OS: ");
                        String idOS = scanner.nextLine();
                        System.out.print("Diagnóstico técnico: ");
                        String diag = scanner.nextLine();

                        osService.registrarDiagnostico(idOS, diag);
                        System.out.println("✓ Diagnóstico registrado com sucesso!");
                    } catch (Exception e) {
                        System.err.println("Erro ao registrar diagnóstico: " + e.getMessage());
                    }
                }
                case 2 -> {
                    try {
                        System.out.print("ID da OS: ");
                        String idOS = scanner.nextLine();
                        System.out.print("Descrição do Serviço Executado: ");
                        String desc = scanner.nextLine();
                        System.out.print("Horas Trabalhadas: ");
                        double horas = Double.parseDouble(scanner.nextLine());
                        System.out.print("Materiais/Peças Utilizados: ");
                        String pecas = scanner.nextLine();

                        osService.registrarIntervencao(idOS, desc, horas, pecas);
                        System.out.println("✓ Intervenção registrada com sucesso!");
                    } catch (Exception e) {
                        System.err.println("Erro ao registrar intervenção: " + e.getMessage());
                    }
                }
                case 3 -> {
                    try {
                        System.out.print("ID da OS a finalizar atendimento: ");
                        String idOS = scanner.nextLine();

                        osService.finalizarManutencaoTecnica(idOS);
                        System.out.println("✓ Manutenção concluída! Status alterado para REPARO_FINALIZADO e técnico liberado.");
                    } catch (Exception e) {
                        System.err.println("Erro ao finalizar manutenção: " + e.getMessage());
                    }
                }
                case 4 -> {
                    try {
                        tecnico.marcarComoAusente();
                        userService.cadastrarUsuario(tecnico);
                        System.out.println("✓ Seu status foi alterado para AUSENTE.");
                    } catch (Exception e) {
                        System.err.println("Erro ao marcar ausência: " + e.getMessage());
                    }
                }
                case 5 -> {
                    List<OrdemDeServico> lista = osService.listarTodas();
                    System.out.println("\n--- LISTA DE ORDENS DE SERVIÇO ---");
                    if (lista.isEmpty()) {
                        System.out.println("Nenhuma Ordem de Serviço encontrada.");
                    } else {
                        lista.forEach(os -> {
                            String tecNome = os.getTecnicoAlocado() != null ? os.getTecnicoAlocado().getNome() : "Sem Técnico";
                            System.out.printf("[%s] Equipamento: %s | Falha: %s | Status: %s | Técnico: %s\n",
                                    os.getId(), os.getEquipamento().getNome(), os.getDescricaoFalha(), os.getStatus(), tecNome);
                        });
                    }
                }
                case 0 -> {
                    System.out.println("Saindo do sistema... Até logo!");
                    rodando = false;
                }
                default -> System.out.println("Opção inválida! Tente novamente.");
            }
        }
    }

    private static int lerOpcaoInt() {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}