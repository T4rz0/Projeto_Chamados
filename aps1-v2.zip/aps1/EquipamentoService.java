package aps1;

import java.util.List;

// Implementação do serviço responsável pelas regras de negócio e operações com Equipamentos
public class EquipamentoService implements IEquipamentoService {
    
    // Dependência da interface do repositório (SOLID - DIP)
    private final EquipamentoRepositorio equipRepo;

    // Construtor: Injeta a implementação do repositório de equipamentos
    public EquipamentoService(EquipamentoRepositorio equipRepo) {
        this.equipRepo = equipRepo;
    }

    // Regra: Persiste um novo equipamento no sistema
    @Override
    public void cadastrar(Equipamento equipamento) {
        equipRepo.salvar(equipamento);
    }

    // Regra: Busca o equipamento pelo ID, inativa através da regra de domínio e salva a alteração
    @Override
    public void inativar(String idEquipamento) {
        Equipamento equip = equipRepo.buscarPorId(idEquipamento)
                .orElseThrow(() -> new IllegalArgumentException("Equipamento não encontrado."));
        
        equip.inativar();
        equipRepo.salvar(equip);
    }

    // Retorna a lista completa de equipamentos cadastrados
    @Override
    public List<Equipamento> listarTodos() {
        return equipRepo.listarTodos();
    }
}