package aps1;

import java.util.List;

// Implementação do serviço responsável pela gestão de Usuários e Técnicos
public class UsuarioService implements IUsuarioService {
    
    // Dependência da interface do repositório de usuários
    private final UsuarioRepositorio usuarioRepo;

    // Construtor: Injeta a implementação do repositório de usuários
    public UsuarioService(UsuarioRepositorio usuarioRepo) {
        this.usuarioRepo = usuarioRepo;
    }

    // Regra: Valida se o usuário não é nulo antes de salvar
    @Override
    public void cadastrarUsuario(Usuario usuario) {
        if (usuario == null) {
            throw new IllegalArgumentException("Usuário não pode ser nulo.");
        }
        usuarioRepo.salvar(usuario);
    }

    // Busca um usuário pelo ID e lança exceção caso não encontre
    @Override
    public Usuario buscarPorId(String id) {
        return usuarioRepo.buscarPorId(id)
                .orElseThrow(() -> new IllegalArgumentException("Usuário não encontrado para o ID: " + id));
    }

    // Filtra e retorna apenas os técnicos com status DISPONIVEL
    @Override
    public List<Tecnico> listarTecnicosDisponiveis() {
        return usuarioRepo.listarTecnicos().stream()
                .filter(tec -> tec.getStatusTec() == StatusTecnico.DISPONIVEL)
                .toList();
    }

    // Retorna todos os técnicos cadastrados, independentemente do status
    @Override
    public List<Tecnico> listarTodosTecnicos() {
        return usuarioRepo.listarTecnicos();
    }
}