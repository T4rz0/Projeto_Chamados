package aps1;

import java.util.List;

// Implementação do serviço responsável por orquestrar o ciclo de vida das Ordens de Serviço
public class OS_Service implements IOS_Service {
    
    // Dependências dos repositórios de OS e Equipamento
    private final OrdemServicoRepositorio osRepo;
    private final EquipamentoRepositorio equipRepo;

    // Construtor: Injeta as dependências necessárias de persistência
    public OS_Service(OrdemServicoRepositorio osRepo, EquipamentoRepositorio equipRepo) {
        this.osRepo = osRepo;
        this.equipRepo = equipRepo;
    }

    // Regra: Busca o equipamento associado e cria uma nova OS com status ABERTA
    @Override
    public OrdemDeServico abrirChamado(String id, String idEquipamento, String falha, String criticidade) {
        Equipamento equipamento = equipRepo.buscarPorId(idEquipamento)
                .orElseThrow(() -> new IllegalArgumentException("Equipamento não encontrado ID: " + idEquipamento));

        OrdemDeServico novaOS = new OrdemDeServico(id, equipamento, falha, criticidade);
        osRepo.salvar(novaOS);
        return novaOS;
    }

    // Regra: Atribui o técnico à OS e altera o status da OS para EM_EXECUCAO
    @Override
    public void atribuirTecnico(String idOS, Tecnico tecnico) {
        OrdemDeServico os = buscarOS(idOS);
        os.atribuirTecnico(tecnico);
        osRepo.salvar(os);
    }

    // Regra: Registra o parecer técnico inicial/diagnóstico do problema
    @Override
    public void registrarDiagnostico(String idOS, String diagnostico) {
        OrdemDeServico os = buscarOS(idOS);
        os.registrarDiagnostico(diagnostico);
        osRepo.salvar(os);
    }

    // Regra: Registra as ações executadas, horas trabalhadas e peças utilizadas
    @Override
    public void registrarIntervencao(String idOS, String descricao, double horas, String pecas) {
        OrdemDeServico os = buscarOS(idOS);
        os.adicionarRegistro(descricao, horas, pecas);
        osRepo.salvar(os);
    }

    // Regra: Finaliza o atendimento técnico, altera status para REPARO_FINALIZADO e libera o técnico
    @Override
    public void finalizarManutencaoTecnica(String idOS) {
        OrdemDeServico os = buscarOS(idOS);
        os.concluirTecnicamente();
        osRepo.salvar(os);
    }

    // Regra: Encerramento administrativo formal da OS realizado pelo gestor
    @Override
    public void fecharPeloGestor(String idOS) {
        OrdemDeServico os = buscarOS(idOS);
        os.fecharPeloGestor();
        osRepo.salvar(os);
    }

    // Retorna a lista completa de Ordens de Serviço
    @Override
    public List<OrdemDeServico> listarTodas() {
        return osRepo.listarTodas();
    }

    // Método utilitário privado para reaproveitar a busca por ID e validação de existência
    private OrdemDeServico buscarOS(String idOS) {
        return osRepo.buscarPorId(idOS)
                .orElseThrow(() -> new IllegalArgumentException("OS não encontrada: " + idOS));
    }
}