package aps1;

import java.util.List;

// Interface do serviço especialista em Usuários e Técnicos
public interface IUsuarioService {
    void cadastrarUsuario(Usuario usuario);
    Usuario buscarPorId(String id);
    List<Tecnico> listarTecnicosDisponiveis();
    List<Tecnico> listarTodosTecnicos();
}