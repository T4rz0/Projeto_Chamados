package aps1;

import java.util.List;

//Interface do serviço especialista em Equipamentos
public interface IEquipamentoService {
 void cadastrar(Equipamento equipamento);
 void inativar(String idEquipamento);
 List<Equipamento> listarTodos();
}