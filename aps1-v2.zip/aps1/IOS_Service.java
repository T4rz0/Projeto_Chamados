package aps1;

import java.util.List;

// Interface do serviço especialista em Ordens de Serviço
public interface IOS_Service {
    OrdemDeServico abrirChamado(String id, String idEquipamento, String falha, String criticidade);
    void atribuirTecnico(String idOS, Tecnico tecnico);
    void registrarDiagnostico(String idOS, String diagnostico);
    void registrarIntervencao(String idOS, String descricao, double horas, String pecas);
    void finalizarManutencaoTecnica(String idOS);
    void fecharPeloGestor(String idOS);
    List<OrdemDeServico> listarTodas();
}